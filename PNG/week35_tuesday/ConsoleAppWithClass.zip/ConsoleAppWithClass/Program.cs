﻿class Program
{
  static void Main(string[] args)
  {
    Vehicle veh = new("Car");
    veh.PrintType();
  }
}