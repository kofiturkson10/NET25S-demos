class Bird
{
    public void Chirp()
    {
        Console.WriteLine("Fågeln säger: kvit kvit");
    }
}