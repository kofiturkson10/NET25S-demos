class Cat
{
    public void Meow()
    {
        Console.WriteLine("Katten säger: mjauuuu");
    }
}