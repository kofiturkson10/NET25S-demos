class Dog
{
    public void Bark()
    {
        Console.WriteLine("Hunden säger: voff voff");
    }
}