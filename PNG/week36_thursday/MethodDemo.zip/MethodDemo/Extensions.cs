public static class Extensions
{
  public static string ToCurrency(this object value)
  {
    return value + " kr";
  }
}