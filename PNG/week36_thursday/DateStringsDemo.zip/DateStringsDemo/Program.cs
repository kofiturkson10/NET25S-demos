﻿class Program
{
    static void Main()
    {
        Helper.DateDemo();
        Helper.StringDemo();
    }
}