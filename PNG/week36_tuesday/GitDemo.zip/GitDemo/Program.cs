﻿Console.WriteLine("Hello, World!");
Console.WriteLine("Bye, World!");
Console.WriteLine("Wow, another line?!");
Console.WriteLine("This is getting ridicilous...");
